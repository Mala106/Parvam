from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3, os, csv
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = 'complaint_secret_2024'
DB = 'complaints.db'

# ── DB helpers ─────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.executescript('''
            CREATE TABLE IF NOT EXISTS users (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT    UNIQUE NOT NULL,
                password TEXT    NOT NULL,
                role     TEXT    NOT NULL DEFAULT 'user'
            );
            CREATE TABLE IF NOT EXISTS complaints (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL,
                name        TEXT    NOT NULL,
                category    TEXT    NOT NULL,
                description TEXT    NOT NULL,
                date        TEXT    NOT NULL,
                status      TEXT    NOT NULL DEFAULT 'Pending',
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
        ''')
        # Seed default accounts
        conn.execute("INSERT OR IGNORE INTO users(username,password,role) VALUES('admin','admin123','admin')")
        conn.execute("INSERT OR IGNORE INTO users(username,password,role) VALUES('user1','user123','user')")
        conn.execute("INSERT OR IGNORE INTO users(username,password,role) VALUES('user2','user456','user')")

        # Seed 30 sample complaints so the system isn't empty
        sample = [
            (2,'Alice','Electricity','Street light not working near Block-A','2024-01-10','Resolved'),
            (2,'Alice','Water','No water supply for 3 days','2024-01-12','Pending'),
            (3,'Bob','Food','Canteen food quality is very poor','2024-01-14','In Progress'),
            (2,'Alice','Other','Garbage not collected for a week','2024-01-15','Pending'),
            (3,'Bob','Electricity','Frequent power cuts in Hostel B','2024-01-17','Resolved'),
            (2,'Alice','Water','Water pipe burst on main road','2024-01-18','In Progress'),
            (3,'Bob','Food','Mess food contains insects','2024-01-20','Pending'),
            (2,'Alice','Electricity','No electricity in reading room','2024-01-21','Resolved'),
            (3,'Bob','Other','Wi-Fi not working in lab','2024-01-22','In Progress'),
            (2,'Alice','Water','Water tank overflowing causing damage','2024-01-23','Pending'),
            (3,'Bob','Electricity','Electricity bill discrepancy','2024-01-25','Resolved'),
            (2,'Alice','Food','Food served cold at dinner','2024-01-26','In Progress'),
            (3,'Bob','Other','Road potholes causing accidents','2024-01-28','Pending'),
            (2,'Alice','Water','Drinking water tastes bad','2024-01-29','Resolved'),
            (3,'Bob','Electricity','Short circuit in room 204','2024-01-30','In Progress'),
            (2,'Alice','Food','Portion size drastically reduced','2024-02-01','Pending'),
            (3,'Bob','Other','Loud noise from construction at night','2024-02-03','Resolved'),
            (2,'Alice','Electricity','AC not working in exam hall','2024-02-05','Pending'),
            (3,'Bob','Water','Water cooler broken in Block-C','2024-02-07','In Progress'),
            (2,'Alice','Food','No vegetarian options available','2024-02-08','Pending'),
            (3,'Bob','Other','Lift malfunction in main building','2024-02-10','Resolved'),
            (2,'Alice','Water','Sewage smell near dining hall','2024-02-12','Pending'),
            (3,'Bob','Electricity','Lights flickering in corridor','2024-02-14','In Progress'),
            (2,'Alice','Food','Overpriced items in canteen','2024-02-15','Pending'),
            (3,'Bob','Other','Parking area flooding in rain','2024-02-17','Resolved'),
            (2,'Alice','Electricity','Generator not starting during outage','2024-02-19','Pending'),
            (3,'Bob','Water','Low water pressure in showers','2024-02-20','In Progress'),
            (2,'Alice','Food','Unhygienic kitchen conditions observed','2024-02-22','Pending'),
            (3,'Bob','Other','CCTV cameras not functioning','2024-02-24','Resolved'),
            (2,'Alice','Water','Rainwater leaking into rooms','2024-02-25','Pending'),
        ]
        conn.executemany(
            "INSERT OR IGNORE INTO complaints(user_id,name,category,description,date,status) VALUES(?,?,?,?,?,?)",
            sample
        )

# ── Auth decorators ────────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get('role') != 'admin':
            flash('Admin access required.', 'error')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated

# ── Routes ─────────────────────────────────────────────────────────────────
@app.route('/', methods=['GET','POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    error = None
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        with get_db() as conn:
            user = conn.execute(
                "SELECT * FROM users WHERE username=? AND password=?",
                (username, password)
            ).fetchone()
        if user:
            session['user_id']  = user['id']
            session['username'] = user['username']
            session['role']     = user['role']
            return redirect(url_for('dashboard'))
        error = 'Invalid username or password.'
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    with get_db() as conn:
        if session['role'] == 'admin':
            cat    = request.args.get('category','')
            status = request.args.get('status','')
            query  = "SELECT * FROM complaints WHERE 1=1"
            params = []
            if cat:
                query += " AND category=?"; params.append(cat)
            if status:
                query += " AND status=?"; params.append(status)
            query += " ORDER BY id DESC"
            complaints = conn.execute(query, params).fetchall()
            total      = conn.execute("SELECT COUNT(*) FROM complaints").fetchone()[0]
            pending    = conn.execute("SELECT COUNT(*) FROM complaints WHERE status='Pending'").fetchone()[0]
            inprog     = conn.execute("SELECT COUNT(*) FROM complaints WHERE status='In Progress'").fetchone()[0]
            resolved   = conn.execute("SELECT COUNT(*) FROM complaints WHERE status='Resolved'").fetchone()[0]
            return render_template('admin_dashboard.html',
                complaints=complaints, total=total,
                pending=pending, inprog=inprog, resolved=resolved,
                sel_cat=cat, sel_status=status)
        else:
            complaints = conn.execute(
                "SELECT * FROM complaints WHERE user_id=? ORDER BY id DESC",
                (session['user_id'],)
            ).fetchall()
            return render_template('user_dashboard.html', complaints=complaints)

@app.route('/submit', methods=['GET','POST'])
@login_required
def submit():
    if session['role'] == 'admin':
        return redirect(url_for('dashboard'))
    predicted = None
    if request.method == 'POST':
        name  = request.form['name'].strip()
        cat   = request.form['category']
        desc  = request.form['description'].strip()
        date  = request.form['date']
        if not all([name, cat, desc, date]):
            flash('All fields are required.', 'error')
        else:
            with get_db() as conn:
                conn.execute(
                    "INSERT INTO complaints(user_id,name,category,description,date,status) VALUES(?,?,?,?,?,?)",
                    (session['user_id'], name, cat, desc, date, 'Pending')
                )
            flash('Complaint submitted successfully!', 'success')
            return redirect(url_for('dashboard'))
    return render_template('submit.html', predicted=predicted)

@app.route('/update_status/<int:cid>', methods=['POST'])
@login_required
@admin_required
def update_status(cid):
    new_status = request.form['status']
    with get_db() as conn:
        conn.execute("UPDATE complaints SET status=? WHERE id=?", (new_status, cid))
    flash('Status updated.', 'success')
    return redirect(url_for('dashboard',
        category=request.args.get('category',''),
        status=request.args.get('status','')))

@app.route('/api/predict', methods=['POST'])
@login_required
def predict():
    """ML auto-suggest endpoint (Step 5 — loaded only if model exists)."""
    try:
        import joblib, re
        model  = joblib.load('ml/category_model.pkl')
        tfidf  = joblib.load('ml/tfidf_vectorizer.pkl')
        text   = request.json.get('text','')
        text   = re.sub(r'[^a-zA-Z\s]','', text.lower())
        vec    = tfidf.transform([text])
        pred   = model.predict(vec)[0]
        return jsonify({'category': pred})
    except Exception:
        return jsonify({'category': None})

@app.route('/export_csv')
@login_required
@admin_required
def export_csv():
    with get_db() as conn:
        rows = conn.execute("SELECT id,user_id,name,category,description,date,status FROM complaints").fetchall()
    path = 'ml/complaints_export.csv'
    os.makedirs('ml', exist_ok=True)
    with open(path,'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['id','user_id','name','category','description','date','status'])
        writer.writerows(rows)
    flash(f'Exported {len(rows)} records to ml/complaints_export.csv', 'success')
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
